
import React, { useState, useEffect } from 'react';
import { Play, Download, Search, User, LogOut, Star, ShieldCheck, Crown, Tv, Mail, Lock, AlertCircle, CheckCircle } from 'lucide-react';
import { initializeApp } from 'firebase/app';
import { 
  getAuth, 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged,
  sendPasswordResetEmail 
} from 'firebase/auth';

const firebaseConfig = {
  apiKey: "AIzaSyDdiKIHf8WfET-orTEsGtu_59gcOEl7Tlo",
  authDomain: "toontool-13288.firebaseapp.com",
  projectId: "toontool-13288",
  storageBucket: "toontool-13288.firebasestorage.app",
  messagingSenderId: "703104343209",
  appId: "1:703104343209:web:d86dff18da7f4f7000ddb8",
  measurementId: "G-BMXZT4LXPW"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

const AuthPage = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [isForgotPassword, setIsForgotPassword] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const handleAuth = async (e) => {
    e.preventDefault();
    setError('');
    setMessage('');
    setLoading(true);

    try {
      if (isForgotPassword) {
        await sendPasswordResetEmail(auth, email);
        setMessage('تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك الإلكتروني.');
        setTimeout(() => setIsForgotPassword(false), 3000);
      } else if (isLogin) {
        await signInWithEmailAndPassword(auth, email, password);
      } else {
        await createUserWithEmailAndPassword(auth, email, password);
      }
    } catch (err) {
      if (err.code === 'auth/email-already-in-use') setError('هذا البريد الإلكتروني مسجل بالفعل.');
      else if (err.code === 'auth/wrong-password' || err.code === 'auth/user-not-found' || err.code === 'auth/invalid-credential') setError('البريد الإلكتروني أو كلمة المرور غير صحيحة.');
      else if (err.code === 'auth/weak-password') setError('كلمة المرور ضعيفة، يجب أن تكون 6 أحرف على الأقل.');
      else setError('حدث خطأ، يرجى المحاولة مرة أخرى.');
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gray-900 flex items-center justify-center p-4 relative overflow-hidden" dir="rtl">
      <div className="absolute top-[-10%] right-[-10%] w-96 h-96 bg-purple-600 rounded-full blur-[150px] opacity-30"></div>
      <div className="absolute bottom-[-10%] left-[-10%] w-96 h-96 bg-blue-600 rounded-full blur-[150px] opacity-30"></div>

      <div className="bg-gray-800/50 backdrop-blur-xl border border-gray-700 p-8 rounded-3xl w-full max-w-md relative z-10 shadow-2xl">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-500 to-blue-500 mb-2 tracking-tighter">
            ToonTool
          </h1>
          <p className="text-gray-400">
            {isForgotPassword ? 'استعادة كلمة المرور' : isLogin ? 'تسجيل الدخول للمتابعة' : 'إنشاء حساب جديد'}
          </p>
        </div>

        {error && (
          <div className="bg-red-500/10 border border-red-500/50 text-red-500 p-3 rounded-xl mb-4 flex items-center gap-2">
            <AlertCircle size={18} />
            <span className="text-sm">{error}</span>
          </div>
        )}

        {message && (
          <div className="bg-green-500/10 border border-green-500/50 text-green-500 p-3 rounded-xl mb-4 flex items-center gap-2">
            <CheckCircle size={18} />
            <span className="text-sm">{message}</span>
          </div>
        )}

        <form onSubmit={handleAuth} className="space-y-4">
          <div>
            <div className="relative">
              <Mail className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <input 
                type="email" 
                placeholder="البريد الإلكتروني" 
                className="w-full bg-gray-900/50 border border-gray-700 text-white rounded-xl py-3 pr-12 pl-4 focus:outline-none focus:border-purple-500 transition-colors"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
          </div>

          {!isForgotPassword && (
            <div>
              <div className="relative">
                <Lock className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                <input 
                  type="password" 
                  placeholder="كلمة المرور" 
                  className="w-full bg-gray-900/50 border border-gray-700 text-white rounded-xl py-3 pr-12 pl-4 focus:outline-none focus:border-purple-500 transition-colors"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
            </div>
          )}

          <button 
            type="submit" 
            disabled={loading}
            className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white font-bold py-3 rounded-xl transition-all shadow-lg hover:shadow-purple-500/25 flex justify-center items-center"
          >
            {loading ? <span className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full"></span> : (isForgotPassword ? 'إرسال الرابط' : isLogin ? 'دخول' : 'إنشاء الحساب')}
          </button>
        </form>

        <div className="mt-6 text-center space-y-2">
          {!isForgotPassword && (
            <button onClick={() => setIsForgotPassword(true)} className="text-sm text-gray-400 hover:text-white transition-colors block w-full">
              نسيت كلمة المرور؟
            </button>
          )}
          
          <button 
            onClick={() => {
              setIsForgotPassword(false);
              setIsLogin(!isLogin);
              setError('');
              setMessage('');
            }} 
            className="text-sm text-purple-400 hover:text-purple-300 transition-colors font-semibold block w-full"
          >
            {isForgotPassword ? 'العودة لتسجيل الدخول' : isLogin ? 'لا تملك حساباً؟ سجل الآن' : 'لديك حساب بالفعل؟ سجل دخولك'}
          </button>
        </div>
      </div>
    </div>
  );
};

const Navbar = ({ user, setCurrentPage }) => (
  <nav className="bg-gray-900/80 backdrop-blur-md sticky top-0 z-50 border-b border-gray-800">
    <div className="container mx-auto px-4 py-4 flex justify-between items-center">
      <div 
        className="flex items-center gap-2 cursor-pointer"
        onClick={() => setCurrentPage('home')}
      >
        <div className="w-10 h-10 bg-gradient-to-tr from-purple-600 to-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-purple-500/30">
          <Play className="text-white fill-white ml-1" size={20} />
        </div>
        <span className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-blue-400 tracking-tighter">
          ToonTool
        </span>
      </div>

      <div className="hidden md:flex flex-1 max-w-xl mx-8">
        <div className="relative w-full">
          <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
          <input 
            type="text" 
            placeholder="ابحث عن أنمي، كرتون، أو فيلم..." 
            className="w-full bg-gray-800 border border-gray-700 text-white rounded-full py-2 pr-12 pl-4 focus:outline-none focus:border-purple-500 transition-colors"
          />
        </div>
      </div>

      <div className="flex items-center gap-4">
        <button 
          onClick={() => setCurrentPage('subscriptions')}
          className="hidden md:flex items-center gap-2 text-yellow-500 hover:text-yellow-400 font-semibold bg-yellow-500/10 px-4 py-2 rounded-full transition-colors border border-yellow-500/20"
        >
          <Crown size={18} /> الباقات
        </button>
        
        <div className="flex items-center gap-3 bg-gray-800 py-1.5 px-3 rounded-full border border-gray-700">
          <div className="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center">
            <User size={16} className="text-white" />
          </div>
          <span className="text-sm font-medium text-gray-300 max-w-[100px] truncate block">
            {user?.email?.split('@')[0]}
          </span>
          <button 
            onClick={() => signOut(auth)}
            className="text-gray-400 hover:text-red-500 transition-colors mr-2"
            title="تسجيل الخروج"
          >
            <LogOut size={18} />
          </button>
        </div>
      </div>
    </div>
  </nav>
);

const HomePage = ({ setCurrentPage }) => {
  const featured = [
    { id: 1, title: 'هجوم العمالقة', type: 'مسلسل مدبلج', rating: '9.8', image: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=500&q=80' },
    { id: 2, title: 'ون بيس', type: 'مسلسل مدبلج', rating: '9.5', image: 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=500&q=80' },
    { id: 3, title: 'قاتل الشياطين', type: 'فيلم مدبلج', rating: '9.7', image: 'https://images.unsplash.com/photo-1541562232579-512a21360020?w=500&q=80' },
    { id: 4, title: 'دراغون بول', type: 'مسلسل مدبلج', rating: '9.4', image: 'https://images.unsplash.com/photo-1618336753974-aae8e04506aa?w=500&q=80' },
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="relative rounded-3xl overflow-hidden h-[400px] mb-12 shadow-2xl shadow-purple-900/20 group">
        <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/60 to-transparent z-10"></div>
        <img src="https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1200&q=80" alt="Hero" className="absolute inset-0 w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700" />
        
        <div className="absolute bottom-0 left-0 right-0 p-8 z-20">
          <div className="inline-block bg-purple-600 text-white text-xs font-bold px-3 py-1 rounded-full mb-3 shadow-lg shadow-purple-500/50">
            حصرياً
          </div>
          <h1 className="text-4xl md:text-5xl font-black text-white mb-4 drop-shadow-lg">
            اكتشف عالم الأنمي المدبلج
          </h1>
          <p className="text-gray-300 max-w-2xl mb-6 text-lg">
            مكتبة ضخمة من المسلسلات والأفلام بجودة 4K وسيرفرات صاروخية، مع نظام حماية كامل.
          </p>
          <div className="flex gap-4">
            <button 
              onClick={() => setCurrentPage('watch')}
              className="bg-white text-gray-900 hover:bg-gray-200 font-bold py-3 px-8 rounded-full flex items-center gap-2 transition-all transform hover:scale-105"
            >
              <Play fill="currentColor" size={20} /> ابدأ المشاهدة
            </button>
            <button 
              onClick={() => setCurrentPage('subscriptions')}
              className="bg-gray-800/80 hover:bg-gray-700 backdrop-blur-md text-white border border-gray-600 font-bold py-3 px-8 rounded-full flex items-center gap-2 transition-all"
            >
              <Crown className="text-yellow-500" size={20} /> اشترك الآن
            </button>
          </div>
        </div>
      </div>

      <div className="mb-8 flex justify-between items-end">
        <div>
          <h2 className="text-2xl font-bold text-white mb-1">أحدث الإضافات</h2>
          <p className="text-gray-400 text-sm">تمت إضافتها حديثاً للموقع</p>
        </div>
        <button className="text-purple-400 hover:text-purple-300 text-sm font-semibold">عرض الكل</button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {featured.map((item) => (
          <div key={item.id} className="group cursor-pointer" onClick={() => setCurrentPage('watch')}>
            <div className="relative rounded-2xl overflow-hidden aspect-[3/4] mb-3">
              <img src={item.image} alt={item.title} className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500" />
              <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-transparent to-transparent opacity-80"></div>
              <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-md text-white text-xs font-bold px-2 py-1 rounded-md flex items-center gap-1 border border-gray-700">
                <Star className="text-yellow-500 fill-yellow-500" size={12} /> {item.rating}
              </div>
              <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-black/40 backdrop-blur-sm">
                <div className="w-14 h-14 bg-purple-600 rounded-full flex items-center justify-center shadow-lg shadow-purple-500/50 transform scale-50 group-hover:scale-100 transition-transform duration-300 delay-100">
                  <Play className="text-white fill-white ml-1" size={24} />
                </div>
              </div>
            </div>
            <h3 className="text-white font-bold text-lg group-hover:text-purple-400 transition-colors">{item.title}</h3>
            <p className="text-gray-400 text-sm">{item.type}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

const WatchPage = ({ setCurrentPage }) => {
  return (
    <div className="container mx-auto px-4 py-8">
      <button onClick={() => setCurrentPage('home')} className="text-gray-400 hover:text-white mb-6 flex items-center gap-2">
        &larr; العودة للرئيسية
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="aspect-video bg-black rounded-2xl overflow-hidden relative shadow-2xl border border-gray-800 mb-6 flex items-center justify-center group">
            <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1578632767115-351597cf2477?w=1200&q=80')] bg-cover bg-center opacity-40"></div>
            
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex flex-col justify-end p-4 z-10">
               <div className="w-full bg-gray-600/50 h-1.5 rounded-full mb-4 overflow-hidden backdrop-blur-md">
                 <div className="w-1/3 bg-purple-500 h-full relative">
                   <div className="absolute left-0 top-1/2 transform -translate-y-1/2 w-3 h-3 bg-white rounded-full shadow-[0_0_10px_rgba(168,85,247,0.8)]"></div>
                 </div>
               </div>
               <div className="flex justify-between items-center text-white">
                 <div className="flex items-center gap-4">
                   <Play fill="white" size={24} className="cursor-pointer hover:text-purple-400 transition-colors" />
                   <span className="text-sm font-medium font-mono">24:15 / 1:45:00</span>
                 </div>
                 <ShieldCheck size={20} className="text-green-400" title="DRM Protected" />
               </div>
            </div>
            
            <div className="relative z-20 w-20 h-20 bg-purple-600/90 rounded-full flex items-center justify-center cursor-pointer shadow-[0_0_30px_rgba(147,51,234,0.6)] hover:scale-110 transition-transform backdrop-blur-sm">
              <Play className="text-white fill-white ml-2" size={32} />
            </div>
          </div>

          <h1 className="text-3xl font-bold text-white mb-2">هجوم العمالقة - الموسم الأخير - الحلقة 1</h1>
          <div className="flex items-center gap-4 text-sm text-gray-400 mb-6">
            <span className="flex items-center gap-1"><Star className="text-yellow-500 fill-yellow-500" size={16} /> 9.8</span>
            <span>2024</span>
            <span className="bg-gray-800 px-2 py-1 rounded text-xs">4K Ultra HD</span>
          </div>

          <p className="text-gray-300 leading-relaxed bg-gray-900/50 p-4 rounded-xl border border-gray-800">
            تبدأ المعركة النهائية حيث يواجه فيلق الاستطلاع تحديات غير مسبوقة. حلقة مليئة بالإثارة والتشويق مع دبلجة احترافية حصرية.
          </p>
        </div>

        <div className="space-y-6">
          <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <Tv size={20} className="text-purple-500" /> سيرفرات المشاهدة
            </h3>
            <div className="space-y-3">
              {['ToonTool Premium (4K)', 'VIP Server 1 (1080p)', 'Fast Server (720p)'].map((server, i) => (
                <button key={i} className={`w-full py-3 px-4 rounded-xl font-semibold flex justify-between items-center transition-all ${i === 0 ? 'bg-purple-600/20 text-purple-400 border border-purple-500/50 hover:bg-purple-600/30' : 'bg-gray-800 text-gray-300 hover:bg-gray-700 border border-gray-700'}`}>
                  <span>{server}</span>
                  {i === 0 && <span className="flex h-2 w-2 relative"><span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-purple-400 opacity-75"></span><span className="relative inline-flex rounded-full h-2 w-2 bg-purple-500"></span></span>}
                </button>
              ))}
            </div>
          </div>

          <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <Download size={20} className="text-blue-500" /> روابط التحميل
            </h3>
            <div className="space-y-3">
              {[
                { res: '4K - 2.5GB', icon: Crown, color: 'text-yellow-500' },
                { res: '1080p - 1.2GB', icon: Download, color: 'text-gray-300' },
                { res: '720p - 600MB', icon: Download, color: 'text-gray-400' }
              ].map((link, i) => (
                <button key={i} className="w-full bg-gray-800 hover:bg-gray-700 border border-gray-700 text-white py-3 px-4 rounded-xl font-medium flex justify-between items-center transition-all group">
                  <span className="flex items-center gap-2">
                    <link.icon size={16} className={link.color} />
                    {link.res}
                  </span>
                  <span className="bg-gray-900 px-3 py-1 rounded-lg text-xs group-hover:bg-blue-600 transition-colors">تحميل</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const SubscriptionsPage = ({ setCurrentPage }) => {
  const plans = [
    { name: 'الأساسية', price: '4.99', features: ['جودة 720p', 'سيرفرات عادية', 'إعلانات قليلة', 'دعم فني عادي'] },
    { name: 'البريميوم', price: '9.99', popular: true, features: ['جودة 1080p & 4K', 'سيرفرات ToonTool السريعة', 'بدون إعلانات نهائياً', 'تحميل غير محدود', 'دعم فني أولوية'] },
    { name: 'العائلية', price: '14.99', features: ['كل مميزات البريميوم', '4 حسابات فرعية', 'مشاركة الحساب', 'محتوى مخصص للأطفال'] },
  ];

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="text-center max-w-2xl mx-auto mb-12">
        <h1 className="text-4xl font-black text-white mb-4">اختر الباقة المناسبة لك</h1>
        <p className="text-gray-400 text-lg">استمتع بتجربة مشاهدة سينمائية خالية من الإعلانات وبأعلى جودة ممكنة.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
        {plans.map((plan, i) => (
          <div key={i} className={`relative bg-gray-900/50 backdrop-blur-xl border ${plan.popular ? 'border-purple-500 shadow-2xl shadow-purple-500/20 transform md:-translate-y-4' : 'border-gray-800'} rounded-3xl p-8 flex flex-col`}>
            {plan.popular && (
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-purple-600 to-blue-600 text-white px-4 py-1 rounded-full text-sm font-bold shadow-lg">
                الأكثر طلباً
              </div>
            )}
            <h3 className="text-2xl font-bold text-white mb-2">{plan.name}</h3>
            <div className="text-gray-400 flex items-end gap-1 mb-6">
              <span className="text-4xl font-black text-white">${plan.price}</span>
              <span className="mb-1">/ شهرياً</span>
            </div>
            
            <ul className="space-y-4 mb-8 flex-1">
              {plan.features.map((feature, j) => (
                <li key={j} className="flex items-center gap-3 text-gray-300">
                  <CheckCircle size={18} className={plan.popular ? 'text-purple-500' : 'text-gray-500'} />
                  {feature}
                </li>
              ))}
            </ul>

            <button className={`w-full py-4 rounded-xl font-bold transition-all ${plan.popular ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white shadow-lg hover:shadow-purple-500/25' : 'bg-gray-800 text-white hover:bg-gray-700'}`}>
              اشترك الآن
            </button>
          </div>
        ))}
      </div>
      
      <div className="text-center mt-12">
        <button onClick={() => setCurrentPage('home')} className="text-gray-400 hover:text-white transition-colors">
          العودة للرئيسية
        </button>
      </div>
    </div>
  );
};

const App = () => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState('home');

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-purple-600"></div>
      </div>
    );
  }

  if (!user) {
    return <AuthPage />;
  }

  return (
    <div className="min-h-screen bg-gray-950 text-gray-100 font-sans" dir="rtl" style={{ fontFamily: 'Cairo, sans-serif' }}>
      <Navbar user={user} setCurrentPage={setCurrentPage} />
      
      <main>
        {currentPage === 'home' && <HomePage setCurrentPage={setCurrentPage} />}
        {currentPage === 'watch' && <WatchPage setCurrentPage={setCurrentPage} />}
        {currentPage === 'subscriptions' && <SubscriptionsPage setCurrentPage={setCurrentPage} />}
      </main>
    </div>
  );
};

export default App;
